# I3ToSQLite
An unofficial i3-file to sqlite database converter
